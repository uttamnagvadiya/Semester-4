import 'dart:convert';
import 'package:http/http.dart' as http;

class UpdateDatabase{

  Future<List> getQuerys() async {
    var requestBody = '''<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <ARCH_AllTable_AllDataResponse xmlns="http://tempuri.org/">
      <ARCH_AllTable_AllDataResult>string</ARCH_AllTable_AllDataResult>
    </ARCH_AllTable_AllDataResponse>
  </soap:Body>
</soap:Envelope>''';

    http.Response data = await http.post(
      Uri.parse('http://aswdc.in/ws/adm_allapp_update.asmx'),
      headers: {
        'content-type': 'text/xml; charset=utf-8',
        'SOAPAction': 'http://tempuri.org/ARCH_AllTable_AllData',
        'Host': 'aswdc.in',
      },
      body: utf8.encode(requestBody),
    );
    print("Response status: ${data.statusCode}");
    // print("Response body: ${data.body}");

    return jsonDecode(data.body.toString());
  }
}